<h1>Honda</h1>
<h2>Menü</h2>
<ul>
    <li><a href="<?php echo e(route('admin.cars')); ?>">Autók listája</a></li>
    <li><a href="<?php echo e(route('admin.bmw')); ?>">BMW</a></li> 
    <li><a href="<?php echo e(route('admin.mercedes')); ?>">Mercedes</a></li>
    <li><a href="<?php echo e(route('admin.honda')); ?>">Honda</a></li>
    <li><a href="<?php echo e(route('admin.volvo')); ?>">Volvo</a></li>
</ul><?php /**PATH C:\xampp\laravel\laravel-routers\resources\views/admin/honda.blade.php ENDPATH**/ ?>