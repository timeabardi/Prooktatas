<h1>Felhasználó megtekintése: #<?php echo e($id); ?></h1>
<h2>Menü</h2>
<ul>
    <li><a href="<?php echo e(route('users.list')); ?>">Felhasználók listázása</a></li>
    <li><a href="<?php echo e(route('users.show', 1)); ?>">Felhasználó megtekintése</a></li> 
    <li><a href="<?php echo e(url('users/show/1')); ?>">Felhasználó megtekintése</a></li>
    <li><a href="<?php echo e(route('users.add', 1)); ?>">Felhasználó hozzáadása</a></li>
    <li><a href="<?php echo e(route('users.edit', 1)); ?>">Felhasználó szerkesztése</a></li>
</ul><?php /**PATH C:\xampp\laravel\laravel-routers\resources\views/users/show.blade.php ENDPATH**/ ?>