<h1>Felhasználók listázása</h1>
<h2>Menü</h2>
<ul>
    <li><a href="<?php echo e(route('users.list')); ?>">Felhasználók listázása</a></li>
    <li><a href="<?php echo e(route('users.show', 1)); ?>">Felhasználó megtekintése</a></li> 
    <li><a href="<?php echo e(url('users/show/1')); ?>">Felhasználó megtekintése</a></li>
    <li><a href="<?php echo e(route('users.add', 1)); ?>">Felhasználó hozzáadása</a></li>
    <li><a href="<?php echo e(route('users.edit', 1)); ?>">Felhasználó szerkesztése</a></li>
</ul>

<p>CSRF token: <?php echo e(csrf_token()); ?></p>
<p>CSRF token in form: </p>
<form>
<?php echo csrf_field(); ?>
<input type=text>
</form>
Add CSRF token to header:
// app/Http/Middleware/VerifyCsrfToken<?php /**PATH C:\xampp\laravel\laravel-routers\resources\views/users/list.blade.php ENDPATH**/ ?>