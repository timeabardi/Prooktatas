<h1>BMW</h1>
<h2>Menü</h2>
<ul>
    <li><a href="{{ route('admin.cars')}}">Autók listája</a></li>
    <li><a href="{{ route('admin.bmw')}}">BMW</a></li> 
    <li><a href="{{ route('admin.mercedes')}}">Mercedes</a></li>
    <li><a href="{{ route('admin.honda')}}">Honda</a></li>
    <li><a href="{{ route('admin.volvo')}}">Volvo</a></li>
</ul>